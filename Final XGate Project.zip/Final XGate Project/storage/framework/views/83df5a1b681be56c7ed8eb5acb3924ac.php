

<?php $__env->startSection('content'); ?>
    <h2 class='text-white'>Projects</h2>
    <a class='text-white' href="<?php echo e(route('projects.create')); ?>">Create Project</a>

    <table>
        <tr>
            <th class='text-white'>Name</th>
            <th class='text-white'>Description</th>
            <th class='text-white'>Actions</th>
        </tr>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class='text-white'><?php echo e($project->name); ?></td>
                <td class='text-white'><?php echo e($project->description); ?></td>
                <td class='text-white'>
                    <a href="<?php echo e(route('projects.show', $project->id)); ?>">View</a>
                    <a href="<?php echo e(route('projects.edit', $project->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dimit\Desktop\Final XGate Project\resources\views/projects/index.blade.php ENDPATH**/ ?>