

<?php $__env->startSection('content'); ?>
    <h2 class='text-white'>Edit Project</h2>
    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <label class='text-white'>Name:</label>
        <input type="text" name="name" value="<?php echo e($project->name); ?>" required>
        <label class='text-white'>Description:</label>
        <textarea name="description"><?php echo e($project->description); ?></textarea>
        <button class='text-white' type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dimit\Desktop\Final XGate Project\resources\views/projects/edit.blade.php ENDPATH**/ ?>