

<?php $__env->startSection('content'); ?>
    <h2 class='text-white'>Create Project</h2>
    <form action="<?php echo e(route('projects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label class='text-white'>Name:</label>
        <input type="text" name="name" required>
        <label class='text-white'>Description:</label>
        <textarea name="description"></textarea>
        <button class='text-white' type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dimit\Desktop\Final XGate Project\resources\views/projects/create.blade.php ENDPATH**/ ?>