

<?php $__env->startSection('content'); ?>
    <h2 class='text-white'>Create Task</h2>
    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label class='text-white'>Title:</label>
        <input type="text" name="title" required>

        <label class='text-white'>Description:</label>
        <textarea name="description"></textarea>

        <label class='text-white'>Project:</label>
        <select name="project_id" required>
            <option value="">Select Project</option>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button class='text-white' type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dimit\Desktop\Final XGate Project\resources\views/tasks/create.blade.php ENDPATH**/ ?>