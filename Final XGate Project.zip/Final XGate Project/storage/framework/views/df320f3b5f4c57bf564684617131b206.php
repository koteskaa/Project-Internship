

<?php $__env->startSection('content'); ?>
    <h2 class='text-white'>Tasks</h2>
    <a class='text-white' href="<?php echo e(route('tasks.create')); ?>">Create Task</a>

    <table>
        <tr class='text-white'>
            <th class='text-white'>Title</th>
            <th class='text-white'>Description</th>
            <th class='text-white'>Project</th>
            <th class='text-white'>Actions</th>
        </tr>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class='text-white'>
                <td class='text-white'><?php echo e($task->title); ?></td>
                <td class='text-white'><?php echo e($task->description); ?></td>
                <td class='text-white'><?php echo e($task->project->name ?? 'No Project'); ?></td>
                <td>
                    <a href="<?php echo e(route('tasks.show', $task->id)); ?>">View</a>
                    <a href="<?php echo e(route('tasks.edit', $task->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dimit\Desktop\Final XGate Project\resources\views/tasks/index.blade.php ENDPATH**/ ?>