@extends('layouts.app')

@section('content')
    <h2 class='text-white'>Create Project</h2>
    <form action="{{ route('projects.store') }}" method="POST">
        @csrf
        <label class='text-white'>Name:</label>
        <input type="text" name="name" required>
        <label class='text-white'>Description:</label>
        <textarea name="description"></textarea>
        <button class='text-white' type="submit">Save</button>
    </form>
@endsection
