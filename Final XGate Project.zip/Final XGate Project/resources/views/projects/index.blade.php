@extends('layouts.app')

@section('content')
    <h2 class='text-white'>Projects</h2>
    <a class='text-white' href="{{ route('projects.create') }}">Create Project</a>

    <table>
        <tr>
            <th class='text-white'>Name</th>
            <th class='text-white'>Description</th>
            <th class='text-white'>Actions</th>
        </tr>
        @foreach ($projects as $project)
            <tr>
                <td class='text-white'>{{ $project->name }}</td>
                <td class='text-white'>{{ $project->description }}</td>
                <td class='text-white'>
                    <a href="{{ route('projects.show', $project->id) }}">View</a>
                    <a href="{{ route('projects.edit', $project->id) }}">Edit</a>
                    <form action="{{ route('projects.destroy', $project->id) }}" method="POST" style="display:inline;">
                        @csrf @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
