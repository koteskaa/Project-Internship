@extends('layouts.app')

@section('content')
    <h2 class='text-white'>Edit Project</h2>
    <form action="{{ route('projects.update', $project->id) }}" method="POST">
        @csrf @method('PUT')
        <label class='text-white'>Name:</label>
        <input type="text" name="name" value="{{ $project->name }}" required>
        <label class='text-white'>Description:</label>
        <textarea name="description">{{ $project->description }}</textarea>
        <button class='text-white' type="submit">Update</button>
    </form>
@endsection
