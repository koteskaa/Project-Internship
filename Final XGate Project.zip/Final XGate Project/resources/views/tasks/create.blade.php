@extends('layouts.app')

@section('content')
    <h2 class='text-white'>Create Task</h2>
    <form action="{{ route('tasks.store') }}" method="POST">
        @csrf
        <label class='text-white'>Title:</label>
        <input type="text" name="title" required>

        <label class='text-white'>Description:</label>
        <textarea name="description"></textarea>

        <label class='text-white'>Project:</label>
        <select name="project_id" required>
            <option value="">Select Project</option>
            @foreach ($projects as $project)
                <option value="{{ $project->id }}">{{ $project->name }}</option>
            @endforeach
        </select>

        <button class='text-white' type="submit">Save</button>
    </form>
@endsection
