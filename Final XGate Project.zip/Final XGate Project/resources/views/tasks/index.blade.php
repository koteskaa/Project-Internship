@extends('layouts.app')

@section('content')
    <h2 class='text-white'>Tasks</h2>
    <a class='text-white' href="{{ route('tasks.create') }}">Create Task</a>

    <table>
        <tr class='text-white'>
            <th class='text-white'>Title</th>
            <th class='text-white'>Description</th>
            <th class='text-white'>Project</th>
            <th class='text-white'>Actions</th>
        </tr>
        @foreach ($tasks as $task)
            <tr class='text-white'>
                <td class='text-white'>{{ $task->title }}</td>
                <td class='text-white'>{{ $task->description }}</td>
                <td class='text-white'>{{ $task->project->name ?? 'No Project' }}</td>
                <td>
                    <a href="{{ route('tasks.show', $task->id) }}">View</a>
                    <a href="{{ route('tasks.edit', $task->id) }}">Edit</a>
                    <form action="{{ route('tasks.destroy', $task->id) }}" method="POST" style="display:inline;">
                        @csrf @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
